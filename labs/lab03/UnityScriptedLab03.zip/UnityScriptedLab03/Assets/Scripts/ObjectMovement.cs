using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectMovement : MonoBehaviour
{
    public float moveSpeed;
    public float turnSpeed;
    void Update()
    {
        transform.Translate(Vector3.up * moveSpeed * Time.deltaTime);
        // transform.Rotate(Vector3.up, turnSpeed * Time.deltaTime);
    }
}
